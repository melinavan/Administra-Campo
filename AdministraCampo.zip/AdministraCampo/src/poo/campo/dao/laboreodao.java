/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.campo.dao;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import poo.campo.ui.Laboreo;
import poo.campo.ui.Lote;

/**
 *
 * @author Normal
 */
public class laboreodao {
    
    
   public static ArrayList<Laboreo> buscarLaboreosConMatriz() {
        ArrayList<Laboreo> arrLaboreo = new ArrayList<Laboreo>();
       
        Conexion cc = new Conexion();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Laboreo la = null;
        String sql = "SELECT * FROM laboreo WHERE idlaboreo=" ;
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
             
                la = new Laboreo();
                la.setIdlaboreo(Integer.parseInt(rs.getString(1)));
                la.setDescripcion(rs.getString(3));
                    
                if (arrLaboreo.isEmpty()) {
                    arrLaboreo.add(0, la);
                } else {
                    arrLaboreo.add(la);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    cc.desconectar();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        return arrLaboreo;
    }
}
