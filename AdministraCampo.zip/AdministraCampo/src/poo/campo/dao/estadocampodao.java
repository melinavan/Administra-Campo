package poo.campo.dao;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import poo.campo.ui.Estadocampo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Normal
 */
public class estadocampodao {
    
    public static ArrayList<Estadocampo> getListEstadocampo() {
        ArrayList<Estadocampo> arrCampos = new ArrayList<Estadocampo>();
        Conexion cc = new Conexion();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Estadocampo c = null;
        String sql = "SELECT * FROM estadocampo";
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c = new Estadocampo();
                c.setIdestadoCampo(Integer.parseInt(rs.getString(1)));
                c.setDescripcion(rs.getString(2));
                if (arrCampos.isEmpty()) {
                    arrCampos.add(0, c);
                } else {
                    arrCampos.add(c);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        return arrCampos;
    }
}
