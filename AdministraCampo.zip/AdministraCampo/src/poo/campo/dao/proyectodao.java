/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.campo.dao;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import poo.campo.ui.Proyecto;
import poo.campo.ui.Proyectolaboreo;

/**
 *
 * @author Normal
 */
public class proyectodao {
    public static String registrarProyecto(Proyecto pro, ArrayList<Proyectolaboreo> arrproylab) {
        String result = null, last = null;
        List<Proyectolaboreo> proylab=new LinkedList<Proyectolaboreo>();
        String sfecha;
        //java.util.Date fe;        
        SimpleDateFormat d = new SimpleDateFormat("YYYY-mm-dd");        
        Integer id=0;
        Conexion cc = new Conexion();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        
        PreparedStatement pst2 = null;
               
        String sql = "INSERT INTO proyecto values(null,?,?,?,?,?,?,?)"; //idproyecto,idlote,feinicio,fefin,idestadoproyecto,responsable,activo,idcultivo
        String sql2 = "INSERT INTO Proyectolaboreo values(null,?,?,?,?,?,?)";
        try {
            pst = cn.prepareStatement(sql);
            pst.setInt(1, pro.getidlote());       
           
            String dateString = d.format( pro.getFeinicio()   );
            pst.setDate(2,Date.valueOf((String)dateString));//('2018-12-10');
            String dateString2=(String.valueOf(pro.getFefin()));
            pst.setDate(3,Date.valueOf((String)dateString2));
            pst.setInt(4, pro.getidestadoproyecto());
            pst.setString(5, pro.getResponsable());
            pst.setBoolean(6, pro.isActivo());
            pst.setInt(7, pro.getidcultivo());
            pst.execute();
            pst = cn.prepareStatement("SELECT MAX(idproyecto) AS id FROM proyecto");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                last = rs.getString(1);  
                id=Integer.parseInt(last);  
                
                Iterator<Proyectolaboreo> iterador= proylab.iterator();
                while (iterador.hasNext()){
                    Proyectolaboreo pl = iterador.next();
                    pst2= cn.prepareStatement(sql2);
                    pst2.setInt(1, id);
                    pst2.setBoolean(2, true);                    
                    pst2.setInt(3, pl.getIdLaboreo());         
                    String dateString3 = d.format( pro.getFeinicio()   );
                    pst2.setDate(2,Date.valueOf((String)dateString3));//('2018-12-10');
                    //pst2.setDate(4,Date.valueOf((String)sfecha));
                    pst2.setString(5, pl.getNota());
                    pst2.setBoolean(6, pro.isActivo());
                    pst2.setInt(7, pro.getCultivo().getIdcultivo());
                    pst2.execute();
                    
                }
            }
            result = "Proyecto registrado con exito, ID:" + last;
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }
}
