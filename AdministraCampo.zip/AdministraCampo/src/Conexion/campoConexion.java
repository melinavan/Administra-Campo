/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import poo.campo.ui.Campo;
/**
 *
 * @author Normal
 */
public class campoConexion {
    private final String tabla = "campo";
    
      public List<Campo> recuperarTodos(Connection conexion) throws SQLException{
      List<Campo> campos = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT  descripcion, superficie FROM " + this.tabla + " ORDER BY descripcion");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            campos.add(new Campo(resultado.getString("descripcion"),  resultado.getInt("superficie")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return campos;
   }
}
