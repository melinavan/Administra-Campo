
package administracampo;
import poo.campo.JFMenu;
/**
 *
 * @author Normal
 */
public class AdministraCampo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFMenu menu=new JFMenu();
        menu.setVisible(true);
    }
    
}
