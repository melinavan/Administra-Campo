-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: camposadmin
-- ------------------------------------------------------
-- Server version	5.7.24-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campo`
--

DROP TABLE IF EXISTS `campo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campo` (
  `idcampo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `superficie` int(11) NOT NULL,
  `idestado` int(11) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idcampo`),
  UNIQUE KEY `idcampo_UNIQUE` (`idcampo`),
  KEY `idestado_idx` (`idestado`),
  CONSTRAINT `idestado` FOREIGN KEY (`idestado`) REFERENCES `estadocampo` (`idestadoCampo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campo`
--

LOCK TABLES `campo` WRITE;
/*!40000 ALTER TABLE `campo` DISABLE KEYS */;
INSERT INTO `campo` VALUES (1,'CAMPO 41A',50,1,''),(2,'CAMPO 40B',100,1,'');
/*!40000 ALTER TABLE `campo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cultivo`
--

DROP TABLE IF EXISTS `cultivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cultivo` (
  `idcultivo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idcultivo`),
  UNIQUE KEY `idcultivo_UNIQUE` (`idcultivo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cultivo`
--

LOCK TABLES `cultivo` WRITE;
/*!40000 ALTER TABLE `cultivo` DISABLE KEYS */;
INSERT INTO `cultivo` VALUES (1,'SOJA',''),(2,'GIRASOL','');
/*!40000 ALTER TABLE `cultivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cultivolaboreo`
--

DROP TABLE IF EXISTS `cultivolaboreo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cultivolaboreo` (
  `idcultivolaboreo` int(11) NOT NULL AUTO_INCREMENT,
  `idcultivo` int(11) NOT NULL,
  `idlaboreo` int(11) NOT NULL,
  `orden` int(11) DEFAULT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idcultivolaboreo`),
  UNIQUE KEY `idcultivolaboreo_UNIQUE` (`idcultivolaboreo`),
  KEY `idcultivolaboreo_idx` (`idcultivo`),
  KEY `idlaboreoapto_idx` (`idlaboreo`),
  CONSTRAINT `idcultivolaboreo` FOREIGN KEY (`idcultivo`) REFERENCES `cultivo` (`idcultivo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idlaboreoapto` FOREIGN KEY (`idlaboreo`) REFERENCES `laboreo` (`idlaboreo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cultivolaboreo`
--

LOCK TABLES `cultivolaboreo` WRITE;
/*!40000 ALTER TABLE `cultivolaboreo` DISABLE KEYS */;
INSERT INTO `cultivolaboreo` VALUES (7,1,1,1,''),(8,1,2,2,''),(11,2,1,1,''),(12,2,2,3,'');
/*!40000 ALTER TABLE `cultivolaboreo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadocampo`
--

DROP TABLE IF EXISTS `estadocampo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estadocampo` (
  `idestadoCampo` int(11) NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idestadoCampo`),
  UNIQUE KEY `idestadoCampo_UNIQUE` (`idestadoCampo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadocampo`
--

LOCK TABLES `estadocampo` WRITE;
/*!40000 ALTER TABLE `estadocampo` DISABLE KEYS */;
INSERT INTO `estadocampo` VALUES (1,'CREADO',''),(2,'TRABAJADO',''),(3,'DESUSO','');
/*!40000 ALTER TABLE `estadocampo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadoproyecto`
--

DROP TABLE IF EXISTS `estadoproyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estadoproyecto` (
  `idestadoproyecto` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idestadoproyecto`),
  UNIQUE KEY `idestadoproyecto_UNIQUE` (`idestadoproyecto`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadoproyecto`
--

LOCK TABLES `estadoproyecto` WRITE;
/*!40000 ALTER TABLE `estadoproyecto` DISABLE KEYS */;
INSERT INTO `estadoproyecto` VALUES (1,'PREPARACION',''),(2,'CANCELADO',''),(3,'POST SIEMBRA',''),(4,'FINALIZADO','');
/*!40000 ALTER TABLE `estadoproyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboreo`
--

DROP TABLE IF EXISTS `laboreo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laboreo` (
  `idlaboreo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idlaboreo`),
  UNIQUE KEY `idlaboreo_UNIQUE` (`idlaboreo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboreo`
--

LOCK TABLES `laboreo` WRITE;
/*!40000 ALTER TABLE `laboreo` DISABLE KEYS */;
INSERT INTO `laboreo` VALUES (1,'Arar',''),(2,'Sembrar','');
/*!40000 ALTER TABLE `laboreo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote`
--

DROP TABLE IF EXISTS `lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lote` (
  `idlote` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `superficie` int(11) NOT NULL,
  `idtiposuelo` int(11) NOT NULL,
  `idcampo` int(11) NOT NULL,
  PRIMARY KEY (`idlote`),
  UNIQUE KEY `idlote_UNIQUE` (`idlote`),
  KEY `idtiposuelos_idx` (`idtiposuelo`),
  KEY `idcampo_idx` (`idcampo`),
  CONSTRAINT `idcampo` FOREIGN KEY (`idcampo`) REFERENCES `campo` (`idcampo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idtiposuelos` FOREIGN KEY (`idtiposuelo`) REFERENCES `tiposuelo` (`idtiposuelo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote`
--

LOCK TABLES `lote` WRITE;
/*!40000 ALTER TABLE `lote` DISABLE KEYS */;
INSERT INTO `lote` VALUES (1,1,'LOTE1',25,1,1),(2,2,'LOTE2',25,1,1);
/*!40000 ALTER TABLE `lote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto` (
  `idproyecto` int(11) NOT NULL AUTO_INCREMENT,
  `idlote` int(11) NOT NULL,
  `feinicio` datetime NOT NULL,
  `fefin` datetime DEFAULT NULL,
  `idestadoproyecto` int(11) NOT NULL,
  `responsable` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  `idcultivo` int(11) DEFAULT NULL,
  PRIMARY KEY (`idproyecto`),
  UNIQUE KEY `idproyecto_UNIQUE` (`idproyecto`),
  KEY `idlote_idx` (`idlote`),
  KEY `idestadoproyecto_idx` (`idestadoproyecto`),
  CONSTRAINT `idestadoproyecto` FOREIGN KEY (`idestadoproyecto`) REFERENCES `estadoproyecto` (`idestadoproyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idlote` FOREIGN KEY (`idlote`) REFERENCES `lote` (`idlote`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto`
--

LOCK TABLES `proyecto` WRITE;
/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` VALUES (1,1,'2018-12-10 00:00:00','2018-12-13 00:00:00',1,'yo','',1);
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectolaboreo`
--

DROP TABLE IF EXISTS `proyectolaboreo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectolaboreo` (
  `idproyectolaboreo` int(11) NOT NULL AUTO_INCREMENT,
  `idproyecto` int(11) NOT NULL,
  `idlaboreo` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `nota` varchar(200) DEFAULT NULL,
  `idlaboreocultivo` int(11) DEFAULT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idproyectolaboreo`),
  UNIQUE KEY `idproyectolaboreo_UNIQUE` (`idproyectolaboreo`),
  KEY `idproyecto_idx` (`idproyecto`),
  KEY `idlaboreo_idx` (`idlaboreo`),
  CONSTRAINT `idlaboreo` FOREIGN KEY (`idlaboreo`) REFERENCES `laboreo` (`idlaboreo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idproyecto` FOREIGN KEY (`idproyecto`) REFERENCES `proyecto` (`idproyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectolaboreo`
--

LOCK TABLES `proyectolaboreo` WRITE;
/*!40000 ALTER TABLE `proyectolaboreo` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectolaboreo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiposuelo`
--

DROP TABLE IF EXISTS `tiposuelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiposuelo` (
  `idtiposuelo` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idtiposuelo`),
  UNIQUE KEY `idtiposuelo_UNIQUE` (`idtiposuelo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiposuelo`
--

LOCK TABLES `tiposuelo` WRITE;
/*!40000 ALTER TABLE `tiposuelo` DISABLE KEYS */;
INSERT INTO `tiposuelo` VALUES (1,1,'SUELO I',''),(2,2,'SUELO II','');
/*!40000 ALTER TABLE `tiposuelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiposuelocultivo`
--

DROP TABLE IF EXISTS `tiposuelocultivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiposuelocultivo` (
  `idtiposuelocultivo` int(11) NOT NULL AUTO_INCREMENT,
  `idtiposuelo` int(11) NOT NULL,
  `idcultivo` int(11) NOT NULL,
  `activo` bit(1) NOT NULL,
  PRIMARY KEY (`idtiposuelocultivo`),
  UNIQUE KEY `idtiposuelocultivo_UNIQUE` (`idtiposuelocultivo`),
  KEY `idtiposuelo_idx` (`idtiposuelo`),
  KEY `idcultivo_idx` (`idcultivo`),
  CONSTRAINT `idcultivo` FOREIGN KEY (`idcultivo`) REFERENCES `cultivo` (`idcultivo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idtiposuelo` FOREIGN KEY (`idtiposuelo`) REFERENCES `tiposuelo` (`idtiposuelo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiposuelocultivo`
--

LOCK TABLES `tiposuelocultivo` WRITE;
/*!40000 ALTER TABLE `tiposuelocultivo` DISABLE KEYS */;
INSERT INTO `tiposuelocultivo` VALUES (1,1,1,''),(2,1,2,'');
/*!40000 ALTER TABLE `tiposuelocultivo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-14  3:42:22
